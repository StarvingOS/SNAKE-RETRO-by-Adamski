# Datenschutzerklärung – Retro Snake

Stand: 21. September 2026

Retro Snake verarbeitet in der aktuellen Version keine personenbezogenen Daten.
Die App benötigt keine Registrierung und keine Anmeldung.
Der persönliche Highscore wird ausschließlich lokal auf dem Android-Gerät gespeichert.
Es findet keine Übertragung dieses Highscores an externe Server statt.
Die aktuelle Version enthält keine Werbung, Analyse-/Tracking-Dienste oder In-App-Käufe.
