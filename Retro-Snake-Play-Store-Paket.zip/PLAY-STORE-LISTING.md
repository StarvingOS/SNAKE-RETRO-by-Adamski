# Retro Snake – Google Play Store

## Kurzbeschreibung
Der klassische Snake-Spielspaß im grünen Retro-Look – einfach, schnell und nostalgisch.

## Vollständige Beschreibung
Retro Snake bringt das zeitlose Spielgefühl der klassischen Handy-Ära zurück.

Steuere deine Schlange, sammle Futter und werde immer länger. Aber Vorsicht: Mit jedem Punkt wird das Spiel schneller!

### Features
- Klassischer grüner Pixel-Look
- Einfache Steuerung per Wischen
- Punktestand und lokaler Highscore
- Steigende Geschwindigkeit
- Pause, Neustart und Game Over
- Offline spielbar
- Keine Anmeldung erforderlich

Retro Snake ist bewusst schlicht gehalten: starten, spielen, Highscore knacken.

Kategorie: Spiel → Arcade
Preis: Kostenlos
