# Retro Snake – Play-Store-Paket

Enthalten:
- App-Icon in mehreren Android-Dichten
- Google-Play-Feature-Grafik
- Store-Kurz- und Langbeschreibung
- Datenschutz-Entwurf
- Release-Hinweise

Für die Veröffentlichung muss aus dem Android-Projekt ein signiertes Android App Bundle (.aab) erzeugt und anschließend in der Google Play Console hochgeladen werden.
